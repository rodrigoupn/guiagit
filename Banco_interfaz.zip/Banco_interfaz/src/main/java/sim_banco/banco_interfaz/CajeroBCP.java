package sim_banco.banco_interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

// Modelo de Cliente con DNI y PIN
class Cliente {
    private String nombre;
    private String dni;
    private String pin;
    private double saldo;

    public Cliente(String nombre, String dni, String pin, double saldo) {
        this.nombre = nombre;
        this.dni = dni;
        this.pin = pin;
        this.saldo = saldo;
    }

    public String getNombre() { return nombre; }
    public String getDni() { return dni; }
    public String getPin() { return pin; }
    public double getSaldo() { return saldo; }

    public void depositar(double monto) {
        saldo += monto;
    }

    public boolean retirar(double monto) {
        if (monto <= saldo) {
            saldo -= monto;
            return true;
        }
        return false;
    }
}

// Interfaz de operaciones bancarias
interface OperacionesBancarias {
    void consultarSaldo(Cliente cliente, JTextArea area);
    void depositar(Cliente cliente, double monto, JTextArea area);
    void retirar(Cliente cliente, double monto, JTextArea area);
}

// Implementación de la interfaz
class Cajero implements OperacionesBancarias {
    public void consultarSaldo(Cliente cliente, JTextArea area) {
        area.setText("Saldo actual: S/ " + cliente.getSaldo());
    }

    public void depositar(Cliente cliente, double monto, JTextArea area) {
        cliente.depositar(monto);
        area.setText("Depósito exitoso. Nuevo saldo: S/ " + cliente.getSaldo());
    }

    public void retirar(Cliente cliente, double monto, JTextArea area) {
        if (cliente.retirar(monto)) {
            area.setText("Retiro exitoso. Nuevo saldo: S/ " + cliente.getSaldo());
        } else {
            area.setText("Fondos insuficientes.");
        }
    }
}

// Interfaz gráfica principal con imagen y validación
public class CajeroBCPGUI extends JFrame {
    private Cliente clienteActual;
    private Cajero cajero = new Cajero();
    private JTextArea outputArea = new JTextArea(5, 30);

    public CajeroBCPGUI(Cliente cliente) {
        this.clienteActual = cliente;
        setTitle("Cajero BCP - Bienvenido, " + cliente.getNombre());
        setSize(450, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Color azulBCP = new Color(0, 51, 153);
        Color naranjaBCP = new Color(255, 102, 0);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BorderLayout(10, 10));

        // Logo
        JLabel logo = new JLabel();
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/logo_bcp.png"));
            Image img = icon.getImage().getScaledInstance(200, 60, Image.SCALE_SMOOTH);
            logo.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            logo.setText("BCP");
        }

        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.WHITE);
        topPanel.add(logo);
        panel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(azulBCP);
        centerPanel.setLayout(new GridLayout(5, 1, 10, 10));

        JButton consultarBtn = new JButton("Consultar Saldo");
        JButton depositarBtn = new JButton("Depositar");
        JButton retirarBtn = new JButton("Retirar");
        JButton salirBtn = new JButton("Salir");

        outputArea.setEditable(false);
        outputArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Acciones
        consultarBtn.addActionListener(e -> {
          cajero.consultarSaldo(clienteActual, outputArea);
          Recibo.preguntarYGenerar(clienteActual, "Consulta de Saldo", 0);
        });
        
        depositarBtn.addActionListener(e -> {
         String input = JOptionPane.showInputDialog(this, "Monto a depositar:");
         if (input != null && !input.isEmpty()) {
         try {
            double monto = Double.parseDouble(input);
            cajero.depositar(clienteActual, monto, outputArea);
            String nroOperacion = Recibo.preguntarYGenerar(clienteActual, "Depósito", monto);
            
            if (!nroOperacion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Depósito exitoso.\nN° de operación: " + nroOperacion);
            }
            
        } catch (NumberFormatException ex) {
            outputArea.setText("Monto inválido.");
        }
    }
});
    
        retirarBtn.addActionListener(e -> {
         String pinIngresado = JOptionPane.showInputDialog(this, "Ingrese su PIN de 4 dígitos:");
         if (!clienteActual.getPin().equals(pinIngresado)) {
             outputArea.setText("PIN incorrecto. Retiro cancelado.");
             return;
    }
        String input = JOptionPane.showInputDialog(this, "Monto a retirar:");
        if (input != null && !input.isEmpty()) {
           try {
            double monto = Double.parseDouble(input);
            cajero.retirar(clienteActual, monto, outputArea);
            Recibo.preguntarYGenerar(clienteActual, "Retiro", monto);
        } catch (NumberFormatException ex) {
            outputArea.setText("Monto inválido.");
        }
    }
});


        salirBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Gracias por usar el BCP.");
            System.exit(0);
        });

        // Estilo botones
        for (JButton btn : new JButton[]{consultarBtn, depositarBtn, retirarBtn, salirBtn}) {
            btn.setBackground(naranjaBCP);
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Arial", Font.BOLD, 14));
        }

        centerPanel.add(consultarBtn);
        centerPanel.add(depositarBtn);
        centerPanel.add(retirarBtn);
        centerPanel.add(salirBtn);
        centerPanel.add(scrollPane);

        panel.add(centerPanel, BorderLayout.CENTER);
        add(panel);
        setVisible(true);
    }
    
    class Recibo {
    public static String preguntarYGenerar(Cliente cliente, String tipoOperacion, double monto) {
        int opcion = JOptionPane.showConfirmDialog(null, "¿Desea generar un recibo?", "Recibo", JOptionPane.YES_NO_OPTION);
        String numeroOperacion = "";
        
        if (opcion == JOptionPane.YES_OPTION) {
            try {
                String fileName = "recibo_" + cliente.getDni() + "_" + System.currentTimeMillis() + ".txt";
                FileWriter writer = new FileWriter(fileName);
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                // Generar número de operación
                numeroOperacion = String.valueOf(1000000000L + new Random().nextLong(9000000000L));

                writer.write("----- BCP Cajero Virtual -----\n");
                writer.write("Fecha: " + dtf.format(LocalDateTime.now()) + "\n");
                writer.write("Cliente: " + cliente.getNombre() + "\n");
                writer.write("DNI: " + cliente.getDni() + "\n");
                writer.write("Operación: " + tipoOperacion + "\n");
                writer.write("N° de Operación: " + numeroOperacion + "\n");

                if (!tipoOperacion.equals("Consulta de Saldo")) {
                    writer.write("Monto: S/ " + monto + "\n");
                }

                writer.write("Saldo actual: S/ " + cliente.getSaldo() + "\n");
                writer.write("-----------------------------\n");

                writer.close();

                Runtime.getRuntime().exec("notepad " + fileName);

            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al generar o abrir el recibo.");
            }
        }
        return numeroOperacion;
    }
}

    // Login por DNI
    public static void main(String[] args) {
        Cliente[] clientes = {
            new Cliente("Juan", "12345678", "1234", 500.0),
            new Cliente("Ana", "87654321", "5678", 1000.0),
            new Cliente("Luis", "11112222", "0000", 750.0)
        };

        int intentos = 0;
        Cliente encontrado = null;

        while (intentos < 3 && encontrado == null) {
            String dni = JOptionPane.showInputDialog(null, "Ingrese su DNI (8 dígitos):");
            if (dni == null) break;

            for (Cliente c : clientes) {
                if (c.getDni().equals(dni)) {
                    encontrado = c;
                    break;
                }
            }

            if (encontrado == null) {
                JOptionPane.showMessageDialog(null, "DNI no encontrado. Intente nuevamente.");
                intentos++;
            }
        }

        if (encontrado != null) {
            new CajeroBCPGUI(encontrado);
        } else {
            JOptionPane.showMessageDialog(null, "Demasiados intentos fallidos. Acceso denegado.");
        }
    }
}